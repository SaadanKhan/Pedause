# from .models import UserRestaurantBooking, Restaurant
# from django.utils import timezone


# def check_restaurant_availability(rest_id, member):
#     try:
#         rest = Restaurant.objects.filter(id=rest_id).first()
#         rest_capacity = rest.capacity
#         user_rest = UserRestaurantBooking.objects.filter(restaurant=rest_id, is_active=True).first()
#         user_rest.restaurant.capacity
#     except Exception as e:
#         return str(e)