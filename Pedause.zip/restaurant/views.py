from django.shortcuts import render
from .serializers import *
from .models import *
from rest_framework.response import Response
from rest_framework import status
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .utils import *
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from accounts.models import CustomUser
from datetime import datetime
from django.utils import timezone


class GetAllRestaurant(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            restaurants = Restaurant.objects.all()
            paginator = PageNumberPagination()
            paginator.page_size = 10
            rooms_paginated = paginator.paginate_queryset(restaurants, request)
            serializer = RestaurantSerializer(rooms_paginated, many=True)

            paginated_response = paginator.get_paginated_response(serializer.data)

            # Customize the response structure
            return Response({
                'success': True,
                'message': 'All restaurants',
                'data': {
                    'restaurants': paginated_response.data,
                    'pagination': {
                        'count': paginator.page.paginator.count,
                        'page_size': paginator.page_size,
                        'current_page': paginator.page.number,
                        'total_pages': paginator.page.paginator.num_pages,
                        'next': paginated_response.data['next'],
                        'previous': paginated_response.data['previous']
                    }
                }
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
                }, status=status.HTTP_400_BAD_REQUEST)


class GetRestaurantByID(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request, id):
        try:
            restaurant = Restaurant.objects.filter(id=id).first()
            if restaurant:
                serializer = RestaurantSerializer(restaurant)
                return Response({
                    'success': True,
                    'message': 'restaurant',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)
            
            else:
                return Response({
                    'success': False,
                    'message': 'restaurant not found'
                }, status=status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
        

class FilterRestaurantByName(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            search_query = request.data.get('name', None)
            if search_query:
                restaurant = Restaurant.objects.filter(name__icontains=search_query)
            else:
                restaurant = Restaurant.objects.all()
            
            paginator = PageNumberPagination()
            paginator.page_size = 10
            rooms_paginated = paginator.paginate_queryset(restaurant, request)
            serializer = RestaurantSerializer(rooms_paginated, many=True)

            paginated_response = paginator.get_paginated_response(serializer.data)

            # Customize the response structure
            return Response({
                'success': True,
                'message': 'restaurants found' if restaurant.exists() else 'No rooms found',
                'data': {
                    'rooms': paginated_response.data,
                    'pagination': {
                        'count': paginator.page.paginator.count,
                        'page_size': paginator.page_size,
                        'current_page': paginator.page.number,
                        'total_pages': paginator.page.paginator.num_pages,
                        'next': paginated_response.data['next'],
                        'previous': paginated_response.data['previous']
                    }
                }
            }, status=status.HTTP_200_OK if restaurant.exists() else status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
        

class AddOrRemoveFavoriteRestaurant(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            restaurant_id = request.data.get('restaurant_id', None)
            if restaurant_id:
                restaurant = Restaurant.objects.filter(id = restaurant_id).first()
                if restaurant:
                    user_fvrt_restaurant = UserFavouriteRestaurant.objects.filter(user = request.user, restaurant = restaurant).first()
                    if user_fvrt_restaurant:
                        user_fvrt_restaurant.delete()
                        return Response({
                            'success': True,
                           'message': 'Restaurant removed from favorites'
                        }, status=status.HTTP_200_OK)
                    else:
                        user_fvrt_restaurant = UserFavouriteRestaurant.objects.create(user = request.user, restaurant = restaurant)
                        return Response({
                            'success': True,
                           'message': 'Restaurant added to favorites'
                        }, status=status.HTTP_201_CREATED)
                    
                else:
                    return Response({
                        'success': False,
                        'message': 'Restaurant not found'
                    }, status=status.HTTP_404_NOT_FOUND)  
                  
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
                }, status=status.HTTP_400_BAD_REQUEST)


class GetAllFavouriteRestaurant(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            user_fvrt_restaurant = UserFavouriteRestaurant.objects.filter(user=request.user).all()
            
            paginator = PageNumberPagination()
            paginator.page_size = 10
            paginated_rooms = paginator.paginate_queryset(user_fvrt_restaurant, request)
            serializer = UserFvrtRestaurantSerializer(paginated_rooms, many=True)
            
            paginated_response = paginator.get_paginated_response(serializer.data)
            
            return Response({
                'success': True,
                'message': 'Favourite restaurant',
                'data': {
                    'restaurant': paginated_response.data,
                    'pagination': {
                        'count': paginator.page.paginator.count,
                        'page_size': paginator.page_size,
                        'current_page': paginator.page.number,
                        'total_pages': paginator.page.paginator.num_pages,
                        'next': paginated_response.data['next'],
                        'previous': paginated_response.data['previous']
                    }
                }
            }, status=status.HTTP_200_OK if user_fvrt_restaurant.exists() else status.HTTP_404_NOT_FOUND)
            
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


class GetAllReviews(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        try:
            reviews = RestaurantReview.objects.all()
            
            paginator = PageNumberPagination()
            paginator.page_size = 10
            paginated_reviews = paginator.paginate_queryset(reviews, request)
            serializer = RestaurantReviewSerializer(paginated_reviews, many=True)
            
            paginated_response = paginator.get_paginated_response(serializer.data)
            
            return Response({
                'success': True,
                'message': 'Reviews',
                'data': {
                    'reviews': paginated_response.data,
                    'pagination': {
                        'count': paginator.page.paginator.count,
                        'page_size': paginator.page_size,
                        'current_page': paginator.page.number,
                        'total_pages': paginator.page.paginator.num_pages,
                        'next': paginated_response.data['next'],
                        'previous': paginated_response.data['previous']
                    }
                }
            }, status=status.HTTP_200_OK if reviews.exists() else status.HTTP_404_NOT_FOUND)
        
        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)


# class BookRestaurant(APIView):
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def post(self, request):
#         try:
#             # Get user and room data from request
#             user = request.user
#             rest_id = request.data.get('rest_id')
#             checkin_date = datetime.strptime(request.data.get('checkin_date'), '%Y-%m-%d %H:%M:%S')
#             checkout_date = datetime.strptime(request.data.get('checkout_date'), '%Y-%m-%d %H:%M:%S')
#             checkin_time = datetime.strptime(request.data.get('checkin_time'), '%H:%M:%S').time()
#             member = request.data.get('members')

#             # Check if room booked
#             if check_restaurant_availability(rest_id, member):
#                 return Response({
#                 'success': False,
#                 'message': 'Restaurant already booked'
#                 }, status=status.HTTP_400_BAD_REQUEST)
            
#             else:
#                 room = Restaurant.objects.filter(id=rest_id).first()
#                 if room:
#                     if int(member) > room.members:
#                         return Response({
#                         'success': False,
#                         'message': 'Room capacity exceeded'
#                         }, status=status.HTTP_400_BAD_REQUEST)
                    
#                     full_name = request.data.get('full_name')
#                     phone = request.data.get('phone')
#                     govt_id = request.data.get('type_id')
#                     email = request.data.get('email')
#                     account_balance = float(request.data.get('account_balance'))

#                     # Calculate either a user can afford to pay
#                     duration = checkin_date - checkout_date
#                     days_to_stay = duration.days
#                     total_expense = room.price_per_day * days_to_stay

#                     if account_balance < total_expense:
#                         return Response({
#                         'success': False,
#                         'message': 'Insufficient account balance'
#                         }, status=status.HTTP_400_BAD_REQUEST)
                    
#                     else:
#                         custom_user = CustomUser.objects.filter(phone=user).first()
#                         custom_user.email = email
#                         custom_user.phone = phone
#                         custom_user.username = full_name
#                         custom_user.govt_id = govt_id
#                         custom_user.account_balance = account_balance
#                         # Deduct the account balance
#                         custom_user.account_balance = account_balance - total_expense
#                         custom_user.save()

#                         # Book the room for the user
#                         user_room = UserRoom(user=custom_user, room=room, checkin_date=checkin_date, checkout_date=checkout_date)
#                         user_room.save()

#                         # Create a ticket
#                         ticket = RoomTicket(user=custom_user, room=room, checkin_date=checkin_date, checkout_date=checkout_date)
#                         ticket.save()

#                         return Response({
#                         'success': True,
#                         'message': 'Room booked successfully',
#                         'data':{
#                             'user_name': custom_user.username,
#                             'user_number': custom_user.phone,
#                             'user_email': custom_user.email,
#                             'user_room': user_room.room.name,
#                             'guests': member,
#                             'checkin_date': checkin_date,
#                             'checkout_date':checkout_date
#                         }
#                         }, status=status.HTTP_201_CREATED)
                
#                 else:
#                     return Response({
#                         'success': False,
#                         'message': 'Room does not exist'
#                         }, status=status.HTTP_400_BAD_REQUEST)
            
            
#         except Exception as e:
#             return Response({
#                 'success': False,
#                 'message': str(e)
#                 }, status=status.HTTP_400_BAD_REQUEST)